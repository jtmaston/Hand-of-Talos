from Arm_Lib import Arm_Device

dev = Arm_Device()
dev.Arm_serial_set_torque(0)
